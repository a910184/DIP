csvread('histogram_lena_drink_reverse.txt');
bar(0:255,ans)